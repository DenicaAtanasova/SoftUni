﻿namespace DungeonsAndCodeWizards.Entities.Characters.Contracts
{
    public interface IAttackable
    {
        void Attack(Character character);
    }
}
