﻿namespace DungeonsAndCodeWizards.Entities.Bags
{
    public class Backpack : Bag
    {
    }
}
