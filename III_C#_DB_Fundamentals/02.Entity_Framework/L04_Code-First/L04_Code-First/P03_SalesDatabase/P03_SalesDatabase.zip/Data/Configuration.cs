﻿
namespace P03_SalesDatabase.Data
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=DENICA-PC\SQLEXPRESS;Database=SalesDb;Integrated Security=True";
    }
}
